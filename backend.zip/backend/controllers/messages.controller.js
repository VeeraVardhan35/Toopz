import { db } from "../config/db.js";
import {
  conversations,
  conversationParticipants,
  messages,
  messageReadReceipts,
  users,
  groups,
} from "../database/schema.js";
import { eq, and, or, desc, sql, ilike, inArray } from "drizzle-orm";
import cloudinary from "../config/cloudinary.js";
import { getIO } from "../config/socket.js";

// Get all conversations for user
export const getConversations = async (req, res) => {
  try {
    const userId = req.user.id;

    const userConversations = await db
      .select({
        id: conversations.id,
        type: conversations.type,
        name: conversations.name,
        avatarUrl: conversations.avatarUrl,
        groupId: conversations.groupId,
        updatedAt: conversations.updatedAt,
        lastMessage: sql`(
          SELECT json_build_object(
            'id', m.id,
            'content', m.content,
            'type', m.type,
            'createdAt', m.created_at,
            'senderId', m.sender_id
          )
          FROM ${messages} m
          WHERE m.conversation_id = ${conversations.id}
          ORDER BY m.created_at DESC
          LIMIT 1
        )`.as("last_message"),
        unreadCount: sql`(
          SELECT COUNT(*)::int
          FROM ${messages} m
          LEFT JOIN ${messageReadReceipts} mrr 
            ON m.id = mrr.message_id AND mrr.user_id = ${userId}
          WHERE m.conversation_id = ${conversations.id}
            AND m.sender_id != ${userId}
            AND mrr.id IS NULL
        )`.as("unread_count"),
      })
      .from(conversationParticipants)
      .leftJoin(
        conversations,
        eq(conversationParticipants.conversationId, conversations.id)
      )
      .where(eq(conversationParticipants.userId, userId))
      .orderBy(desc(conversations.updatedAt));

    // Get other participants for direct chats
    const conversationsWithParticipants = await Promise.all(
      userConversations.map(async (conv) => {
        if (conv.type === "direct") {
          const [otherUser] = await db
            .select({
              id: users.id,
              name: users.name,
              profileUrl: users.profileUrl,
            })
            .from(conversationParticipants)
            .leftJoin(users, eq(conversationParticipants.userId, users.id))
            .where(
              and(
                eq(conversationParticipants.conversationId, conv.id),
                sql`${conversationParticipants.userId} != ${userId}`
              )
            );

          return {
            ...conv,
            otherUser,
          };
        } else {
          // Group chat
          const participants = await db
            .select({
              id: users.id,
              name: users.name,
              profileUrl: users.profileUrl,
            })
            .from(conversationParticipants)
            .leftJoin(users, eq(conversationParticipants.userId, users.id))
            .where(eq(conversationParticipants.conversationId, conv.id));

          return {
            ...conv,
            participants,
          };
        }
      })
    );

    return res.status(200).json({
      success: true,
      conversations: conversationsWithParticipants,
    });
  } catch (error) {
    console.error("Get conversations error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch conversations",
    });
  }
};

// Get or create direct conversation
export const getOrCreateConversation = async (req, res) => {
  try {
    const userId = req.user.id;
    const { otherUserId } = req.body;

    if (!otherUserId) {
      return res.status(400).json({
        success: false,
        message: "Other user ID is required",
      });
    }

    // Check if conversation already exists
    const existingConversation = await db
      .select({
        id: conversations.id,
      })
      .from(conversationParticipants)
      .leftJoin(
        conversations,
        eq(conversationParticipants.conversationId, conversations.id)
      )
      .where(
        and(
          eq(conversations.type, "direct"),
          eq(conversationParticipants.userId, userId)
        )
      );

    for (const conv of existingConversation) {
      const [hasOtherUser] = await db
        .select()
        .from(conversationParticipants)
        .where(
          and(
            eq(conversationParticipants.conversationId, conv.id),
            eq(conversationParticipants.userId, otherUserId)
          )
        );

      if (hasOtherUser) {
        // Get other user info
        const [otherUser] = await db
          .select({
            id: users.id,
            name: users.name,
            profileUrl: users.profileUrl,
          })
          .from(users)
          .where(eq(users.id, otherUserId));

        return res.status(200).json({
          success: true,
          conversation: {
            id: conv.id,
            type: "direct",
            otherUser,
          },
        });
      }
    }

    // Create new conversation
    const [newConversation] = await db
      .insert(conversations)
      .values({
        universityId: req.user.universityId,
        type: "direct",
        createdBy: userId,
      })
      .returning();

    // Add participants
    await db.insert(conversationParticipants).values([
      {
        conversationId: newConversation.id,
        userId: userId,
      },
      {
        conversationId: newConversation.id,
        userId: otherUserId,
      },
    ]);

    // Get other user info
    const [otherUser] = await db
      .select({
        id: users.id,
        name: users.name,
        profileUrl: users.profileUrl,
      })
      .from(users)
      .where(eq(users.id, otherUserId));

    return res.status(201).json({
      success: true,
      conversation: {
        ...newConversation,
        otherUser,
      },
    });
  } catch (error) {
    console.error("Get or create conversation error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to create conversation",
    });
  }
};

// Get messages in a conversation
export const getMessages = async (req, res) => {
  try {
    const userId = req.user.id;
    const { conversationId } = req.params;
    const { limit = 50, before } = req.query;

    // Verify user is participant
    const [isParticipant] = await db
      .select()
      .from(conversationParticipants)
      .where(
        and(
          eq(conversationParticipants.conversationId, conversationId),
          eq(conversationParticipants.userId, userId)
        )
      );

    if (!isParticipant) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to view this conversation",
      });
    }

    let conditions = [eq(messages.conversationId, conversationId)];

    if (before) {
      conditions.push(sql`${messages.createdAt} < ${new Date(before)}`);
    }

    const conversationMessages = await db
      .select({
        id: messages.id,
        content: messages.content,
        type: messages.type,
        fileUrl: messages.fileUrl,
        fileName: messages.fileName,
        fileSize: messages.fileSize,
        isEdited: messages.isEdited,
        isDeleted: messages.isDeleted,
        replyToId: messages.replyToId,
        createdAt: messages.createdAt,
        sender: {
          id: users.id,
          name: users.name,
          profileUrl: users.profileUrl,
        },
      })
      .from(messages)
      .leftJoin(users, eq(messages.senderId, users.id))
      .where(and(...conditions))
      .orderBy(desc(messages.createdAt))
      .limit(parseInt(limit));

    return res.status(200).json({
      success: true,
      messages: conversationMessages.reverse(),
    });
  } catch (error) {
    console.error("Get messages error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch messages",
    });
  }
};

// Send message
export const sendMessage = async (req, res) => {
  try {
    const userId = req.user.id;
    const { conversationId } = req.params;
    const { content, type = "text", replyToId } = req.body;
    const file = req.file;

    let fileUrl = null;
    let fileName = null;
    let fileSize = null;

    // Upload file to Cloudinary if present
    if (file) {
      const upload = await cloudinary.uploader.upload(file.path, {
        resource_type: "auto",
        folder: "messages",
      });

      fileUrl = upload.secure_url;
      fileName = file.originalname;
      fileSize = file.size;
    }

    // Create message
    const [newMessage] = await db
      .insert(messages)
      .values({
        conversationId,
        senderId: userId,
        content,
        type,
        fileUrl,
        fileName,
        fileSize,
        replyToId,
      })
      .returning();

    // Update conversation timestamp
    await db
      .update(conversations)
      .set({ updatedAt: new Date() })
      .where(eq(conversations.id, conversationId));

    // Get sender info
    const [sender] = await db
      .select({
        id: users.id,
        name: users.name,
        profileUrl: users.profileUrl,
      })
      .from(users)
      .where(eq(users.id, userId));

    const messageWithSender = {
      ...newMessage,
      sender,
    };

    // Emit via Socket.IO
    const io = getIO();
    io.to(`conversation_${conversationId}`).emit("new_message", messageWithSender);

    return res.status(201).json({
      success: true,
      message: messageWithSender,
    });
  } catch (error) {
    console.error("Send message error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to send message",
    });
  }
};

// Mark messages as read
export const markAsRead = async (req, res) => {
  try {
    const userId = req.user.id;
    const { conversationId } = req.params;

    // Get all unread messages in conversation
    const unreadMessages = await db
      .select({ id: messages.id })
      .from(messages)
      .leftJoin(
        messageReadReceipts,
        and(
          eq(messageReadReceipts.messageId, messages.id),
          eq(messageReadReceipts.userId, userId)
        )
      )
      .where(
        and(
          eq(messages.conversationId, conversationId),
          sql`${messages.senderId} != ${userId}`,
          sql`${messageReadReceipts.id} IS NULL`
        )
      );

    if (unreadMessages.length > 0) {
      await db.insert(messageReadReceipts).values(
        unreadMessages.map((msg) => ({
          messageId: msg.id,
          userId,
        }))
      );
    }

    // Update last read timestamp
    await db
      .update(conversationParticipants)
      .set({ lastReadAt: new Date() })
      .where(
        and(
          eq(conversationParticipants.conversationId, conversationId),
          eq(conversationParticipants.userId, userId)
        )
      );

    return res.status(200).json({
      success: true,
      message: "Messages marked as read",
    });
  } catch (error) {
    console.error("Mark as read error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to mark messages as read",
    });
  }
};

// Edit message
export const editMessage = async (req, res) => {
  try {
    const userId = req.user.id;
    const { messageId } = req.params;
    const { content } = req.body;

    const [message] = await db
      .select()
      .from(messages)
      .where(eq(messages.id, messageId));

    if (!message) {
      return res.status(404).json({
        success: false,
        message: "Message not found",
      });
    }

    if (message.senderId !== userId) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to edit this message",
      });
    }

    const [updatedMessage] = await db
      .update(messages)
      .set({
        content,
        isEdited: true,
        updatedAt: new Date(),
      })
      .where(eq(messages.id, messageId))
      .returning();

    // Emit via Socket.IO
    const io = getIO();
    io.to(`conversation_${message.conversationId}`).emit("message_edited", updatedMessage);

    return res.status(200).json({
      success: true,
      message: updatedMessage,
    });
  } catch (error) {
    console.error("Edit message error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to edit message",
    });
  }
};

// Delete message
export const deleteMessage = async (req, res) => {
  try {
    const userId = req.user.id;
    const { messageId } = req.params;

    const [message] = await db
      .select()
      .from(messages)
      .where(eq(messages.id, messageId));

    if (!message) {
      return res.status(404).json({
        success: false,
        message: "Message not found",
      });
    }

    if (message.senderId !== userId) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to delete this message",
      });
    }

    // Soft delete
    await db
      .update(messages)
      .set({
        isDeleted: true,
        content: "This message was deleted",
        updatedAt: new Date(),
      })
      .where(eq(messages.id, messageId));

    // Emit via Socket.IO
    const io = getIO();
    io.to(`conversation_${message.conversationId}`).emit("message_deleted", {
      messageId,
    });

    return res.status(200).json({
      success: true,
      message: "Message deleted",
    });
  } catch (error) {
    console.error("Delete message error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to delete message",
    });
  }
};

// Search conversations
export const searchConversations = async (req, res) => {
  try {
    const userId = req.user.id;
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        message: "Search query is required",
      });
    }

    // Search users for direct chats
    const searchedUsers = await db
      .select({
        id: users.id,
        name: users.name,
        profileUrl: users.profileUrl,
        email: users.email,
      })
      .from(users)
      .where(
        and(
          sql`${users.id} != ${userId}`,
          eq(users.universityId, req.user.universityId),
          or(
            ilike(users.name, `%${q}%`),
            ilike(users.email, `%${q}%`)
          )
        )
      )
      .limit(10);

    return res.status(200).json({
      success: true,
      users: searchedUsers,
    });
  } catch (error) {
    console.error("Search conversations error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to search",
    });
  }
};