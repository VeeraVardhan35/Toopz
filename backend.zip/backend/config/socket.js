import { Server } from "socket.io";
import { db } from "./db.js";
import { messages, messageReadReceipts, conversationParticipants } from "../database/schema.js";
import { eq, and } from "drizzle-orm";

let io;

export const initializeSocket = (server) => {
  io = new Server(server, {
    cors: {
      origin: "http://localhost:5173", // Your frontend URL
      credentials: true,
    },
  });

  const userSockets = new Map(); // userId -> socketId mapping

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    // User authentication
    socket.on("authenticate", (userId) => {
      socket.userId = userId;
      userSockets.set(userId, socket.id);
      console.log(`User ${userId} authenticated with socket ${socket.id}`);
    });

    // Join conversation room
    socket.on("join_conversation", (conversationId) => {
      socket.join(`conversation_${conversationId}`);
      console.log(`User ${socket.userId} joined conversation ${conversationId}`);
    });

    // Leave conversation room
    socket.on("leave_conversation", (conversationId) => {
      socket.leave(`conversation_${conversationId}`);
      console.log(`User ${socket.userId} left conversation ${conversationId}`);
    });

    // Send message
    socket.on("send_message", async (data) => {
      try {
        const { conversationId, content, type, fileUrl, fileName, fileSize } = data;

        // Save message to database
        const [newMessage] = await db
          .insert(messages)
          .values({
            conversationId,
            senderId: socket.userId,
            content,
            type: type || "text",
            fileUrl,
            fileName,
            fileSize,
          })
          .returning();

        // Broadcast to conversation room
        io.to(`conversation_${conversationId}`).emit("new_message", {
          ...newMessage,
          sender: data.sender, // Include sender info from client
        });
      } catch (error) {
        console.error("Send message error:", error);
        socket.emit("error", { message: "Failed to send message" });
      }
    });

    // Typing indicator
    socket.on("typing_start", ({ conversationId, userName }) => {
      socket.to(`conversation_${conversationId}`).emit("user_typing", {
        userId: socket.userId,
        userName,
      });
    });

    socket.on("typing_stop", ({ conversationId }) => {
      socket.to(`conversation_${conversationId}`).emit("user_stopped_typing", {
        userId: socket.userId,
      });
    });

    // Mark message as read
    socket.on("mark_as_read", async ({ messageId, conversationId }) => {
      try {
        await db.insert(messageReadReceipts).values({
          messageId,
          userId: socket.userId,
        });

        // Notify sender
        io.to(`conversation_${conversationId}`).emit("message_read", {
          messageId,
          userId: socket.userId,
        });
      } catch (error) {
        console.error("Mark as read error:", error);
      }
    });

    // Disconnect
    socket.on("disconnect", () => {
      if (socket.userId) {
        userSockets.delete(socket.userId);
      }
      console.log("User disconnected:", socket.id);
    });
  });

  return io;
};

export const getIO = () => {
  if (!io) {
    throw new Error("Socket.io not initialized");
  }
  return io;
};