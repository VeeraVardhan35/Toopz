ALTER TABLE "users" ALTER COLUMN "department" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "users" ALTER COLUMN "batch" DROP NOT NULL;