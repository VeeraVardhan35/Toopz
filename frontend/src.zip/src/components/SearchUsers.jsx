import { useState, useEffect } from "react";
import { searchUsers } from "../api/messages.api";

export default function SearchUsers({ onSelectUser, onClose }) {
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  const DEFAULT_PROFILE_IMAGE =
    "https://cdn-icons-png.flaticon.com/512/847/847969.png";

  // Fetch all users when component mounts or when query changes
  useEffect(() => {
    handleSearch(query);
  }, [query]);

  const handleSearch = async (searchQuery) => {
    try {
      setLoading(true);
      // Search even with empty query to get all users
      const response = await searchUsers(searchQuery || "");
      setUsers(response.users || []);
    } catch (error) {
      console.error("Search users error:", error);
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative">
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search users to chat..."
          className="w-full bg-[#2C3440] text-white px-4 py-2 pl-10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          autoFocus
        />
        <svg
          className="w-5 h-5 text-gray-400 absolute left-3 top-2.5"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
          />
        </svg>
        {query && (
          <button
            onClick={() => setQuery("")}
            className="absolute right-3 top-2.5 text-gray-400 hover:text-white"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        )}
      </div>

      {/* Search Results - Always show when search is active */}
      <div className="absolute z-10 w-full mt-2 bg-[#1E2329] border border-gray-700 rounded-lg shadow-lg max-h-80 overflow-y-auto">
        {loading ? (
          <div className="p-4 text-center text-gray-400">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500 mx-auto mb-2"></div>
            Searching...
          </div>
        ) : users.length === 0 ? (
          <div className="p-4 text-center text-gray-400">
            {query ? `No users found matching "${query}"` : "No users available"}
          </div>
        ) : (
          <>
            <div className="p-2 text-xs text-gray-400 border-b border-gray-700 sticky top-0 bg-[#1E2329]">
              {users.length} user{users.length !== 1 ? "s" : ""} found
              {query && ` matching "${query}"`}
            </div>
            {users.map((user) => (
              <button
                key={user.id}
                onClick={() => {
                  onSelectUser(user.id);
                  setQuery("");
                  setUsers([]);
                }}
                className="w-full p-3 hover:bg-[#252B36] flex items-center gap-3 text-left transition-colors border-b border-gray-800 last:border-b-0"
              >
                <img
                  src={user.profileUrl || DEFAULT_PROFILE_IMAGE}
                  alt={user.name}
                  className="w-10 h-10 rounded-full object-cover border-2 border-gray-700"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-white font-semibold truncate">{user.name}</p>
                  <p className="text-sm text-gray-400 truncate">{user.email}</p>
                </div>
                <svg
                  className="w-5 h-5 text-blue-500 flex-shrink-0"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                  />
                </svg>
              </button>
            ))}
          </>
        )}
      </div>
    </div>
  );
}