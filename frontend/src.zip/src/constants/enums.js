export const DEPARTMENTS = [
    "Computer Science and Engineering",
    "Electronics and Communication",
    "Electrical Engineering",
    "Mechanical Engineering",
    "Smart Manufacturing",
    "Civil Engineering",
    "Chemical Engineering",
    "Design",
    "others",
];

export const BATCHES = [
    "2020",
    "2021",
    "2022",
    "2023",
    "2024",
    "2025",
];

export const GROUP_TYPES = [
    "Academic",
    "Cultural",
    "Sports",
    "Technical",
    "Professional",
    "Special",
];

export const MEDIA_TYPES = [
    "IMAGE",
    "VIDEO",
    "AUDIO",
    "DOCUMENT",
];

export const ROLE_TYPES = [
    "admin",
    "member",
    "coordinator",
    "co-coordinator",
    "captain",
    "Mentor",
];
