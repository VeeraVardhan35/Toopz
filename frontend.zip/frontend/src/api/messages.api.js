import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5500/api/v1/messages",
  withCredentials: true,
});

// Get all conversations
export const getConversations = async () => {
  try {
    const response = await API.get("/conversations");
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Get or create direct conversation
export const getOrCreateConversation = async (otherUserId) => {
  try {
    const response = await API.post("/conversations/direct", { otherUserId });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Get messages in a conversation
export const getMessages = async (conversationId, limit = 50, before = null) => {
  try {
    const response = await API.get(`/conversations/${conversationId}/messages`, {
      params: { limit, before },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Send message (without Socket.IO)
export const sendMessage = async (conversationId, data) => {
  try {
    const formData = new FormData();
    formData.append("content", data.content);
    formData.append("type", data.type || "text");
    if (data.file) {
      formData.append("file", data.file);
    }

    const response = await API.post(
      `/conversations/${conversationId}/messages`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Mark messages as read
export const markAsRead = async (conversationId) => {
  try {
    const response = await API.put(`/conversations/${conversationId}/read`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Edit message
export const editMessage = async (messageId, content) => {
  try {
    const response = await API.put(`/messages/${messageId}`, { content });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Delete message
export const deleteMessage = async (messageId) => {
  try {
    const response = await API.delete(`/messages/${messageId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Search users
export const searchUsers = async (query) => {
  try {
    const response = await API.get("/conversations/search", {
      params: { q: query },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Search conversations
export const searchConversations = async (req, res) => {
  try {
    const userId = req.user.id;
    const { q } = req.query;

    let whereConditions = [
      sql`${users.id} != ${userId}`,
      eq(users.universityId, req.user.universityId),
    ];

    // Add search conditions only if query is provided
    if (q && q.trim()) {
      whereConditions.push(
        or(
          ilike(users.name, `%${q}%`),
          ilike(users.email, `%${q}%`)
        )
      );
    }

    // Search users for direct chats
    const searchedUsers = await db
      .select({
        id: users.id,
        name: users.name,
        profileUrl: users.profileUrl,
        email: users.email,
        department: users.department,
        batch: users.batch,
      })
      .from(users)
      .where(and(...whereConditions))
      .orderBy(users.name)
      .limit(50); // Increased limit to show more users

    return res.status(200).json({
      success: true,
      users: searchedUsers,
    });
  } catch (error) {
    console.error("Search conversations error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to search",
    });
  }
};